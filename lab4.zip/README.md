# lab4 - Systems 2 - CSE 2431

Full Name: Jason Tysl
Date: 11/11/20
To Run: make all, then ./main